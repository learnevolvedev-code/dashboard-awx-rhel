# AWX Telemetry Weekly Report Automation

Ansible automation that collects AWX job and host telemetry data via the AWX REST API, generates a formatted Excel report, emails it via SMTP (Outlook/Office 365), and uploads it to SharePoint via the Microsoft Graph API.

---

## Project Structure

```
awx_telemetry_report/
├── site.yml                          # Main playbook (entry point)
├── ansible.cfg                       # Ansible configuration
├── requirements.yml                  # Collection dependencies
├── .ansible-lint                     # Lint profile
├── inventory/
│   └── hosts.yml                     # localhost only
├── group_vars/
│   └── all.yml                       # All variables (vault refs for secrets)
└── roles/
    ├── awx_collect_telemetry/        # Role 1: API data collection
    │   ├── defaults/main.yml
    │   ├── meta/main.yml
    │   └── tasks/
    │       ├── main.yml
    │       ├── paginate_jobs.yml
    │       ├── enrich_job.yml
    │       ├── collect_host_summaries.yml
    │       └── paginate_host_summaries.yml
    ├── generate_excel_report/        # Role 2: Excel generation
    │   ├── defaults/main.yml
    │   ├── meta/main.yml
    │   ├── files/
    │   │   └── generate_excel.py     # Python/openpyxl script
    │   └── tasks/main.yml
    ├── send_email_report/            # Role 3: SMTP email
    │   ├── defaults/main.yml
    │   ├── meta/main.yml
    │   └── tasks/main.yml
    └── upload_sharepoint/            # Role 4: Graph API upload
        ├── defaults/main.yml
        ├── meta/main.yml
        └── tasks/main.yml
```

---

## Report Data (Mirrors SQL Query Grain)

**1 row = 1 host in 1 job execution**, containing:

| Category | Fields |
|---|---|
| Job metadata | ID, name, status, launch type, job type, playbook, forks, timeout, timestamps |
| Timing | Created, started, finished times |
| Infrastructure | Execution node, controller node |
| Template / Org | Template ID & name, organization, inventory, project, launched-by |
| Execution Environment | EE ID, name, image |
| Host identity | Host ID, host name |
| Host outcome | Status (successful/failed/unreachable), boolean flags |
| Host task counters | OK, changed, failures, unreachable, skipped, ignored, rescued, processed |

---

## AWX Setup Guide

### Step 1 — Credentials

Create the following **Custom Credential Types** and Credentials in AWX:

#### Custom Credential Type: AWX API Token

**Input Configuration (YAML):**
```yaml
fields:
  - id: awx_url
    type: string
    label: AWX URL
  - id: awx_token
    type: string
    label: AWX API Token
    secret: true
required:
  - awx_url
  - awx_token
```

**Injector Configuration (YAML):**
```yaml
extra_vars:
  vault_awx_url: "{{ awx_url }}"
  vault_awx_token: "{{ awx_token }}"
```

#### Custom Credential Type: SMTP

**Input Configuration (YAML):**
```yaml
fields:
  - id: smtp_host
    type: string
    label: SMTP Host
  - id: smtp_username
    type: string
    label: SMTP Username
  - id: smtp_password
    type: string
    label: SMTP Password
    secret: true
  - id: smtp_from
    type: string
    label: From Address
  - id: report_recipient_1
    type: string
    label: Primary Recipient Email
required:
  - smtp_host
  - smtp_username
  - smtp_password
  - smtp_from
  - report_recipient_1
```

**Injector Configuration (YAML):**
```yaml
extra_vars:
  vault_smtp_host: "{{ smtp_host }}"
  vault_smtp_username: "{{ smtp_username }}"
  vault_smtp_password: "{{ smtp_password }}"
  vault_smtp_from: "{{ smtp_from }}"
  vault_report_recipient_1: "{{ report_recipient_1 }}"
```

#### Custom Credential Type: SharePoint / Graph API

**Input Configuration (YAML):**
```yaml
fields:
  - id: sharepoint_tenant_id
    type: string
    label: Azure Tenant ID
  - id: sharepoint_client_id
    type: string
    label: App Registration Client ID
  - id: sharepoint_client_secret
    type: string
    label: App Registration Client Secret
    secret: true
  - id: sharepoint_site_id
    type: string
    label: SharePoint Site ID
  - id: sharepoint_drive_id
    type: string
    label: SharePoint Drive ID
required:
  - sharepoint_tenant_id
  - sharepoint_client_id
  - sharepoint_client_secret
  - sharepoint_site_id
  - sharepoint_drive_id
```

**Injector Configuration (YAML):**
```yaml
extra_vars:
  vault_sharepoint_tenant_id: "{{ sharepoint_tenant_id }}"
  vault_sharepoint_client_id: "{{ sharepoint_client_id }}"
  vault_sharepoint_client_secret: "{{ sharepoint_client_secret }}"
  vault_sharepoint_site_id: "{{ sharepoint_site_id }}"
  vault_sharepoint_drive_id: "{{ sharepoint_drive_id }}"
```

---

### Step 2 — SharePoint App Registration (Azure Portal)

1. Go to **Azure Portal → App registrations → New registration**
2. Name: `AWX-Telemetry-SP-Upload`
3. After creation, go to **API permissions → Add a permission → Microsoft Graph → Application permissions**:
   - `Files.ReadWrite.All`
   - `Sites.ReadWrite.All`
4. Click **Grant admin consent**
5. Go to **Certificates & secrets → New client secret** — note the value (use as `sharepoint_client_secret`)

**Find your SharePoint Site ID and Drive ID:**
```bash
# Get Site ID
curl -H "Authorization: Bearer <token>" \
  "https://graph.microsoft.com/v1.0/sites/<tenant>.sharepoint.com:/sites/<sitename>"

# Get Drive ID (document library)
curl -H "Authorization: Bearer <token>" \
  "https://graph.microsoft.com/v1.0/sites/<site_id>/drives"
```

---

### Step 3 — AWX Project & Job Template

1. **Create Project** → point to this Git repository
2. **Create Job Template:**
   - Name: `AWX Weekly Telemetry Report`
   - Playbook: `site.yml`
   - Inventory: `inventory/hosts.yml` (or AWX localhost inventory)
   - Credentials: attach all three credentials created above
   - Execution Environment: use one with `python3` + `pip` available
3. **Create Schedule** on the Job Template:
   - Name: `Weekly Sunday Midnight`
   - Start: Sunday 00:00 UTC
   - Frequency: Weekly

---

### Step 4 — Run Ad-Hoc with Custom Date Range

Pass `report_start_override` and `report_end_override` as **Extra Variables** in the Job Template launch:

```yaml
report_start_override: "2026-06-01T00:00:00Z"
report_end_override:   "2026-06-07T23:59:59Z"
```

---

## Local Development & Lint

```bash
# Install dependencies
pip install ansible ansible-lint openpyxl
ansible-galaxy collection install -r requirements.yml

# Lint
ansible-lint site.yml

# Dry run (check mode — skips API calls and file writes)
ansible-playbook site.yml --check -e "report_start_override=2026-06-01T00:00:00Z" \
  -e "report_end_override=2026-06-07T23:59:59Z"
```

---

## Idempotency

| Concern | How it is handled |
|---|---|
| Report already generated | `creates:` on the Python script task skips re-generation |
| SharePoint file exists | Graph API `conflictBehavior: replace` overwrites silently |
| Email sent twice | SMTP send is not guarded (intentional — email is best-effort) |
| Re-run same week | Same filename is used; SharePoint replace ensures no duplicates |
