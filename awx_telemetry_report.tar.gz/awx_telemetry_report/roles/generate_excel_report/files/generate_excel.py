#!/usr/bin/env python3
"""
generate_excel.py
=================
Standalone Python script invoked by the generate_excel_report Ansible role.
Reads telemetry JSON, writes a formatted Excel .xlsx report.

Dependencies: openpyxl (installed by Ansible role)
"""

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

try:
    import openpyxl
    from openpyxl.styles import (
        Alignment, Border, Font, PatternFill, Side
    )
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.table import Table, TableStyleInfo
except ImportError:
    print("ERROR: openpyxl is not installed. Run: pip install openpyxl", file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# Column definitions (order = Excel column order)
# ---------------------------------------------------------------------------
COLUMNS = [
    ("execution_id",                "Execution ID",             14),
    ("execution_type",              "Type",                      8),
    ("job_name",                    "Job Name",                 36),
    ("job_status",                  "Job Status",               14),
    ("launch_type",                 "Launch Type",              14),
    ("job_type",                    "Job Type",                 12),
    ("playbook",                    "Playbook",                 30),
    ("forks",                       "Forks",                     8),
    ("timeout",                     "Timeout (s)",              12),
    ("created_time",                "Created Time",             22),
    ("start_time",                  "Start Time",               22),
    ("end_time",                    "End Time",                 22),
    ("execution_node",              "Execution Node",           24),
    ("controller_node",             "Controller Node",          24),
    ("template_id",                 "Template ID",              12),
    ("template_name",               "Template Name",            30),
    ("organization_name",           "Organization",             24),
    ("inventory_name",              "Inventory",                24),
    ("project_name",                "Project",                  24),
    ("launched_by",                 "Launched By",              20),
    ("execution_environment_name",  "EE Name",                  24),
    ("execution_environment_image", "EE Image",                 40),
    ("job_host_summary_id",         "Host Summary ID",          16),
    ("host_id",                     "Host ID",                  10),
    ("host_name",                   "Host Name",                30),
    ("host_status",                 "Host Status",              14),
    ("is_host_success",             "Success Flag",             14),
    ("is_host_failed",              "Failed Flag",              12),
    ("is_host_unreachable",         "Unreachable Flag",         18),
    ("host_failed_boolean",         "Host Failed Bool",         16),
    ("host_ok",                     "OK Tasks",                 10),
    ("host_changed",                "Changed Tasks",            14),
    ("host_failures",               "Failed Tasks",             14),
    ("host_unreachable",            "Unreachable",              14),
    ("host_skipped",                "Skipped Tasks",            14),
    ("host_ignored",                "Ignored Tasks",            14),
    ("host_rescued",                "Rescued Tasks",            14),
    ("host_processed",              "Processed Tasks",          16),
]


def parse_args():
    p = argparse.ArgumentParser(description="Generate AWX Telemetry Excel Report")
    p.add_argument("--input",            required=True, help="Path to input JSON file")
    p.add_argument("--output",           required=True, help="Path for output .xlsx file")
    p.add_argument("--title",            default="AWX Weekly Telemetry Report")
    p.add_argument("--sheet",            default="Job Host Detail")
    p.add_argument("--start-ts",         default="")
    p.add_argument("--end-ts",           default="")
    p.add_argument("--color-success",    default="C6EFCE")
    p.add_argument("--color-failed",     default="FFC7CE")
    p.add_argument("--color-unreachable", default="FFEB9C")
    p.add_argument("--color-unknown",    default="D9D9D9")
    return p.parse_args()


def make_fill(hex_color: str) -> PatternFill:
    return PatternFill(start_color=hex_color, end_color=hex_color, fill_type="solid")


def make_border() -> Border:
    thin = Side(style="thin", color="CCCCCC")
    return Border(left=thin, right=thin, top=thin, bottom=thin)


def write_report(args):
    # ------------------------------------------------------------------
    # Load data
    # ------------------------------------------------------------------
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"ERROR: Input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    with open(input_path, "r", encoding="utf-8") as fh:
        rows = json.load(fh)

    print(f"Loaded {len(rows)} rows from {input_path}")

    # ------------------------------------------------------------------
    # Create workbook
    # ------------------------------------------------------------------
    wb = openpyxl.Workbook()

    # -- Summary sheet (first sheet) -----------------------------------
    ws_summary = wb.active
    ws_summary.title = "Summary"

    header_font = Font(name="Calibri", bold=True, size=14, color="FFFFFF")
    header_fill = make_fill("1F4E79")  # Dark navy

    ws_summary["A1"] = args.title
    ws_summary["A1"].font = Font(name="Calibri", bold=True, size=16, color="1F4E79")
    ws_summary["A2"] = f"Report Period: {args.start_ts}  →  {args.end_ts}"
    ws_summary["A3"] = f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC"
    ws_summary["A4"] = f"Total Host-Job Rows: {len(rows)}"

    total_jobs  = len({r.get("execution_id") for r in rows})
    total_hosts = len({r.get("host_name") for r in rows})
    host_ok     = sum(1 for r in rows if r.get("host_status") == "successful")
    host_fail   = sum(1 for r in rows if r.get("host_status") == "failed")
    host_unr    = sum(1 for r in rows if r.get("host_status") == "unreachable")

    summary_data = [
        ["Metric", "Value"],
        ["Total Unique Jobs",                  total_jobs],
        ["Total Unique Hosts",                 total_hosts],
        ["Total Host Executions",              len(rows)],
        ["Successful Host Executions",         host_ok],
        ["Failed Host Executions",             host_fail],
        ["Unreachable Host Executions",        host_unr],
        ["Success Rate (%)",
         round(host_ok / len(rows) * 100, 2) if rows else 0],
    ]

    ws_summary.column_dimensions["A"].width = 32
    ws_summary.column_dimensions["B"].width = 18

    start_row = 6
    for i, (label, value) in enumerate(summary_data):
        r = start_row + i
        ws_summary.cell(row=r, column=1, value=label)
        ws_summary.cell(row=r, column=2, value=value)
        if i == 0:
            for col in [1, 2]:
                cell = ws_summary.cell(row=r, column=col)
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal="center")

    # -- Detail sheet --------------------------------------------------
    ws = wb.create_sheet(title=args.sheet)

    status_fills = {
        "successful":  make_fill(args.color_success),
        "failed":      make_fill(args.color_failed),
        "unreachable": make_fill(args.color_unreachable),
    }
    default_fill = make_fill(args.color_unknown)

    # Header row
    header_fill_detail = make_fill("1F4E79")
    border = make_border()

    for col_idx, (_, header, width) in enumerate(COLUMNS, start=1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.font = Font(name="Calibri", bold=True, size=10, color="FFFFFF")
        cell.fill = header_fill_detail
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = border
        ws.column_dimensions[get_column_letter(col_idx)].width = width

    ws.row_dimensions[1].height = 30

    # Data rows
    host_status_col = next(
        (i + 1 for i, (k, _, _) in enumerate(COLUMNS) if k == "host_status"), None
    )

    for row_idx, row_data in enumerate(rows, start=2):
        status = str(row_data.get("host_status", "")).lower()
        row_fill = status_fills.get(status, default_fill)

        for col_idx, (key, _, _) in enumerate(COLUMNS, start=1):
            value = row_data.get(key, "")
            # Normalise booleans for readability
            if isinstance(value, bool):
                value = "Yes" if value else "No"
            cell = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.font = Font(name="Calibri", size=9)
            cell.border = border
            cell.alignment = Alignment(vertical="center")
            # Colour only the host_status column; rest gets subtle row banding
            if col_idx == host_status_col:
                cell.fill = row_fill
            elif row_idx % 2 == 0:
                cell.fill = make_fill("F2F2F2")

    # Freeze header row
    ws.freeze_panes = "A2"

    # Auto-filter on header row
    ws.auto_filter.ref = (
        f"A1:{get_column_letter(len(COLUMNS))}1"
    )

    # Excel Table (enables easy sorting/filtering in Excel UI)
    last_col_letter = get_column_letter(len(COLUMNS))
    last_row = len(rows) + 1
    if last_row > 1:
        table = Table(
            displayName="TelemetryData",
            ref=f"A1:{last_col_letter}{last_row}"
        )
        table.tableStyleInfo = TableStyleInfo(
            name="TableStyleMedium9",
            showFirstColumn=False,
            showLastColumn=False,
            showRowStripes=True,
            showColumnStripes=False,
        )
        ws.add_table(table)

    # ------------------------------------------------------------------
    # Save
    # ------------------------------------------------------------------
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(output_path))
    print(f"Excel report saved: {output_path}  ({output_path.stat().st_size:,} bytes)")


if __name__ == "__main__":
    write_report(parse_args())
